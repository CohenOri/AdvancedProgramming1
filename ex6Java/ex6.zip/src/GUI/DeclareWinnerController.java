package GUI;

// we don't need it much, but just in case..
// I'm going to set winner text from other class
public class DeclareWinnerController {
}
