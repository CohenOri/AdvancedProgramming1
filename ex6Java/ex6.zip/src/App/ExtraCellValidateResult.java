package App;

/**
* when checking another cell we get the result, bad place (can't place there tag)
* good place, or we have to check the next cell
*/
public enum ExtraCellValidateResult {
    BAD,
    GOOD,
    AGAIN;
}
