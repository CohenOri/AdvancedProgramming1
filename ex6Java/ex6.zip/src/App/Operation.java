package App;

/**
 * receives an operation to do to a row/col
 */
public  enum Operation {
  NOTHING,
  PLUS,
  MINUS,
};
